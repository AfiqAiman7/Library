<!DOCTYPE html>
<html>
<head>
	<title>List of Books</title>
</head>
<body>
	<form name="rtnbook" method="post" action="rtnBook.php">
		<h2 align="center">
				<b>BOOK DETAILS</b>
		</h2>
		<table align="center">
			<tr>
				<td>BOOK ID</td>
				<td>TITLE</td>
				<td>AUTHOR</td>
				<td>ISBN</td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<tr align="center">
				<td height="50px"><input type="submit" value="UPDATE"></td>
				<td height="50px"><input type="submit" value="DELETE"></td>
				<td height="50px"><input type="submit" value="ADD"></td>
			</tr>

		</table>
	</form>
</body>
</html>