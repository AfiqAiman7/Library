<html>
    <head>
        <title>Generate Monthly Report</title>
    </head>
    <body>
        <form name="report" method="post">
            <h2 align="center"> Generate Monthly Report </h2>
            
        </form>
    </body>
</html>