<?php
	$cStaff_ID=$_GET['fStaff_ID'];
	$cStaff_Name=$_POST['fStaff_Name'];
	$cStaff_PhoneNum=$_POST['fStaff_PhoneNum'];
	$cBranch=$_POST['fBranch'];
	$cHD_ID=$_POST['fHD_ID'];
	$cStaff_Pass=$_POST['fStaff_Pass'];
	$dbc=mysqli_connect("localhost","root","","library");
		if(mysqli_connect_errno())
		{
			echo"Failed to connect to MYSQL: ".mysqli_connect_error();
		}
	$update="update staff set `Staff_ID`='$cStaff_ID',`Staff_Name`='$cStaff_Name',`Staff_PhoneNum`='$cStaff_PhoneNum',
	`Branch`='$cBranch', `HD_ID`='$cHD_ID', `Staff_Pass`='$cStaff_Pass' where `Staff_ID`='$cStaff_ID'";
	$chksql=mysqli_query($dbc,$update);
	if ($chksql) 
	{
		Print '<script>alert("Record had been Updated");</script>';
		Print '<script>window.location.assign("liststaff.php");</script>';

	}
	else
	{
		Print '<script>alert("Record Failed to be Updated");</script>';
		Print '<script>window.location.assign("liststaff.php");</script>';

	}
?>