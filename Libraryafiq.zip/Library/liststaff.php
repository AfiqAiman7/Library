<html>
    <head>
        <title>Staffs' List</title>
    </head>
    <body>
        <form>
        <h3 align="center"><font color="#0000FF">Staffs' Details</font></h3>
        <table align="center" border="1">
            <tr>
                <th>Staff ID</th>
                <td>Staff Name</td>
                <td>Staff Phone No</td>
                <td>Branch</td>
                <td>Staff Pass</td>
                <td>Head Department ID</td>
                <th colspan="2"><font color="#0000FF">Action</font></th>
            </tr>
            
            <?php
                // Connection to the server and datbase
                $dbc = mysqli_connect ("localhost","root","","library");
                if (mysqli_connect_errno()){
                    echo "Failed to connect to MySQL: ".mysqli_connect_error();
                }
                $sql = "select * from `staff`";
                $result = mysqli_query($dbc, $sql);
                while($row = mysqli_fetch_assoc($result)){
                    //Case sensitive on $row var!
                    Print 
                    '<tr>
                        <td>'.$row['Staff_ID'].'</font> </td>
                        <td>'.$row['Staff_Name'].'</font> </td>
                        <td>'.$row['Staff_Phone_Num'].'</font> </td>
                        <td>'.$row['Branch'].'</font> </td>
                        <td>'.$row['HD_ID'].'</font> </td>
                        <td>'.$row['Event_ID'].'</font> </td>
                        <td> <a href="frmupdstaff.php?fStaff_ID='.$row['Staff_ID'].'" class="btn btn-warning" role="button">Update</a> </td>
                        <td> <a href="frmupdstaff.php?fStaff_ID='.$row['Staff_ID'].'" class="btn btn-warning" role="button">Update</a> </td>
                        <td> <a href="frmupdstaff.php?fStaff_ID='.$row['Staff_ID'].'" class="btn btn-warning" role="button">Update</a> </td>
                        <td> <a href="frmupdstaff.php?fStaff_ID='.$row['Staff_ID'].'" class="btn btn-warning" role="button">Update</a> </td>
                        <td> <a href="frmupdstaff.php?fStaff_ID='.$row['Staff_ID'].'" class="btn btn-warning" role="button">Update</a> </td>
                        <td> <a href="frmupdstaff.php?fStaff_ID='.$row['Staff_ID'].'" class="btn btn-warning" role="button">Update</a> </td>
                    </tr>';
                }
            ?>
        </table>
        </form>
    </body>
</html>