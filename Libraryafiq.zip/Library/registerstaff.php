<?php
    $s_ID=$_GET['fStaff_ID'];
    $s_Name=$_POST['fStaff_Name'];
    $s_Phone_Num=$_POST['fStaff_PhoneNum'];
    $sBranch=$_POST['fBranch'];
    $s_Pass=$_POST['fStaff_Pass'];
    $sHD_ID=$_POST['fHD_ID'];

    $dbc=mysqli_connect("localhost","root","","library");
        if(mysqli_connect_errno())
        {
            echo"Failed to connect to MYSQL: ".mysqli_connect_error();
        }

    $sql="insert into `staff`(`Staff_ID`,`Staff_Name`,`Staff_PhoneNum`,`Branch`,`Staff_Pass`,`HD_ID`) values ('$s_ID','$s_Name','$s_PhoneNum','$sBranch','s_Pass','sHD_ID')";
    $results= mysqli_query($dbc,$sql);
    if ($results)
    {
        mysqli_commit($dbc);
        //display message box Record Been Added
        print '<script>alert("Record Had Been Added");</script>';
        //go to frmcustomer.php page
        print '<script>window.location.assign("staffregistrationform.php");</script>';
    }
    else
    { 
        mysqli_rollback($dbc);
        //display error message box
        print '<script>alert("Data Is Invalid , No Record Been Added");</script>';
        //go to frmcustomer.php page
        print '<script>window.location.assign("staffregistrationform.php");</script>';
    }
?>