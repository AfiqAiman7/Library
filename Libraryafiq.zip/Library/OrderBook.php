<html>
    <head>
        <title>Order Book</title>
    </head>
    <body>
        <form>
        <h3 align="center">Order Book</font></h3>
        <table align="center" border="0">
            <tr>
                <td>Book ID</td>
                <td><input name="Book_ID" type="text"></td>
            </tr>
            <tr>
                <td>Book Title</td>
                <td><input name="Book_Title" type="text"></td>
            </tr>
            <tr>
                <td>No Of Pages</td>
                <td><input name="No_Pages" type="text"></td>
            </tr>
            <tr>
                <td>Author Name</td>
                <td><input name="Author_Name" type="text"></td>
            </tr>
            <tr>
                <td>ISBN</td>
                <td><input name="ISBN" type="text"></td>
            </tr>
            <tr>
                <td>Publisher Name</td>
                <td><input name="Publisher_Name" type="text"></td>
            </tr>
            <tr>
                <td>Staff ID</td>
                <td><input name="Staff_ID" type="text"></td>
            </tr>
            <td colspan="2" align="center" height="50px">
                <input type="submit" name="btnsubmit" value="Submit" />      
            </td>
        </table>
        </form>
    </body>
</html>